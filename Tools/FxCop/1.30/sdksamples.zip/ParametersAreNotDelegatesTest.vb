' ParametersAreNotDelegatesTest.vb
Imports System

Namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples

    Public Class ParametersAreNotDelegatesTest

        Delegate Sub Notifier(value As Integer)

        Sub Test1(someNotifier As Notifier)
            someNotifier(1)
        End Sub

        Protected Sub Test2(someNotifier As Notifier)
            someNotifier(2)
        End Sub

        ' This method will not be checked as the sample 
        ' rules only test Public and Protected methods.
        Private Sub Test3(someNotifier As Notifier)
            someNotifier(3)
        End Sub

    End Class
End Namespace