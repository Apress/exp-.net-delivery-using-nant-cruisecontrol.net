// ParametersAreNotDelegatesResourceBased.cs

using System;
using System.Reflection;
using Microsoft.Tools.FxCop.Sdk;
using Microsoft.Tools.FxCop.Sdk.Reflection;

namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples
{
    public class ParametersAreNotDelegatesResourceBased : 
                    BaseReflectionRule, IParameterRule
    {
        // Arguments for the base class:
        // The type name of the rule.
        // The name of the XML resource file.
        // The assembly that contains the XML file.
        public ParametersAreNotDelegatesResourceBased() : 
            base("ParametersAreNotDelegatesResourceBased", 
                 "ParametersAreNotDelegatesResources", 
                 typeof(ParametersAreNotDelegatesResourceBased).Assembly)
        {}

        public object Check(Module parentModule, 
                            ParameterInfo parameter)
        {
            Type parameterType = parameter.ParameterType;

            if (parameterType.IsSubclassOf(typeof(Delegate)))
            {
                return GetResolution(parameterType.Name);
            }
            else
            {
                return null;
            }
        }

        public override ProtectionLevels NestedTypeProtectionLevel 
        { 
            get
            {
                return ProtectionLevels.Public | 
                       ProtectionLevels.Family | 
                       ProtectionLevels.NestedAssembly;
            }
        } 
    }   
}