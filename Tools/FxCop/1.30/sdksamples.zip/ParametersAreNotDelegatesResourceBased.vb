' ParametersAreNotDelegatesResourceBased.vb

Imports System
Imports System.Reflection
Imports Microsoft.Tools.FxCop.Sdk
Imports Microsoft.Tools.FxCop.Sdk.Reflection

Namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples

    Public Class ParametersAreNotDelegatesResourceBased 
        Inherits BaseReflectionRule
        Implements IParameterRule

        ' Arguments for the base class:
        ' The type name of the rule.
        ' The name of the XML resource file.
        ' The assembly that contains the XML file.
        Sub New
            MyBase.New( _
            "ParametersAreNotDelegatesResourceBased", _
            "ParametersAreNotDelegatesResources", _
            GetType(ParametersAreNotDelegatesResourceBased).Assembly)
        End Sub

        Function Check(parentModule As System.Reflection.Module, _
            parameter As ParameterInfo) As Object _
            Implements IParameterRule.Check

            Dim parameterType As Type = parameter.ParameterType

            If parameterType.IsSubclassOf(GetType([Delegate])) Then
                Return GetResolution(parameterType.Name)
            Else
                Return Nothing
            End If
        End Function

        Overrides Readonly Property NestedTypeProtectionLevel _
            As ProtectionLevels

            Get
                Return ProtectionLevels.Public Or _ 
                       ProtectionLevels.Family Or _
                       ProtectionLevels.NestedAssembly
            End Get
        End Property

    End Class
End Namespace