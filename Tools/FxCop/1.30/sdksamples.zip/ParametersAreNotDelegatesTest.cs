// ParametersAreNotDelegatesTest.cs

using System;

namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples
{
    public class ParametersAreNotDelegatesTest
    {
        public delegate void Notifier(int value);

        public void Test1(Notifier someNotifier)
        {
            someNotifier(1);
        }

        protected void Test2(Notifier someNotifier)
        {
            someNotifier(2);
        }

        // This method will not be checked as the sample 
        // rules only test public and protected methods.
        private void Test3(Notifier someNotifier)
        {
            someNotifier(3);
        }
    }
}