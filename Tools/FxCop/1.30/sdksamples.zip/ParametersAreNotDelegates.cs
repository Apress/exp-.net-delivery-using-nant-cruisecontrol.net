// ParametersAreNotDelegates.cs

using System;
using System.Globalization;
using System.Reflection;
using System.Xml;
using Microsoft.Tools.FxCop.Sdk;
using Microsoft.Tools.FxCop.Sdk.Reflection;

namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples
{
    public class ParametersAreNotDelegates : IParameterRule
    {
        public object Check(Module parentModule, 
                            ParameterInfo parameter)
        {
            Type parameterType = parameter.ParameterType;

            // Check whether the parameter is a delegate type.
            if(parameterType.IsSubclassOf(typeof(Delegate)))
            {
                // Return the name of the parameter.
                return parameterType.Name;
            }
            else
            {
                // No violation occurred.
                return null;
            }
        }

        // Set the IReflectionRule property values.

        public ProtectionLevels TypeProtectionLevel 
        { 
            get{return ProtectionLevels.Public | 
                       ProtectionLevels.Family;}
        } 

        public ProtectionLevels NestedTypeProtectionLevel 
        { 
            get{return ProtectionLevels.Public | 
                       ProtectionLevels.Family | 
                       ProtectionLevels.Assembly;}
        } 
      
        public ProtectionLevels MemberProtectionLevel 
        { 
            get{return ProtectionLevels.Public | 
                       ProtectionLevels.Family;}
        } 

        // Set the IRule property values.
           
        public string Name
        {
            get{return "Do not use delegate parameters (SDK sample 1)";}
        }

        public string Description 
        { 
            get{return "Company policy states that parameters should " +
                       "not be delegates.";}
        }

        public string LongDescription 
        {
            get{return "Methods that require delegates should " +
                       "be redesigned. Consider using the " +
                       ".NET event model.";}
        }

        public MessageLevel MessageLevel
        {
            get{return MessageLevel.CriticalError;}
        }

        public int    CertaintyHigh {get{return 99;}} 
        public int    CertaintyLow  {get{return 99;}} 
        public string GroupOwner {get{return "FxCop Custom Rules Team";}}
        public string DevOwner   {get{return "Jane Developer";}} 
        public string Url        {get{return "http://www.example.com";}}
        public string Email      {get{return "JaneD@example.com";}}
      
        // Implement the IRule Methods.

        public string DisplayResolution(object value)
        {
            return String.Format(
                CultureInfo.CurrentUICulture,
                "'{0}' cannot be used as a parameter in an " +
                "externally visible method.",
                value.ToString());
        }

        public object LoadResolution(XmlNode value)
        {
            return value.InnerText;
        }

        public void SaveResolution(XmlWriter writer, object value)
        {
            writer.WriteString(value.ToString());
        }

        public void BeforeAnalysis() {}
        public void AfterAnalysis() {}
    }
}