' ParametersAreNotDelegates.vb

Imports System
Imports System.Globalization
Imports System.Reflection
Imports System.Xml
Imports Microsoft.Tools.FxCop.Sdk
Imports Microsoft.Tools.FxCop.Sdk.Reflection

Namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples

    Public Class ParametersAreNotDelegates
        Implements IParameterRule

        Function Check(parentModule As System.Reflection.Module, _
            parameter As ParameterInfo) As Object _
            Implements IParameterRule.Check

            Dim parameterType As Type = parameter.ParameterType

            ' Check whether the parameter is a delegate type.
            If parameterType.IsSubclassOf(GetType(System.Delegate)) Then

                ' Return the name of the parameter.
                Return parameterType.Name
            Else

                ' No violation occurred.
                Return Nothing
            End If
        End Function

        ' Set the IReflectionRule property values.

        ReadOnly Property TypeProtectionLevel As ProtectionLevels _
            Implements IParameterRule.TypeProtectionLevel
            Get 
                Return ProtectionLevels.Public Or _
                       ProtectionLevels.Family
            End Get
        End Property

        ReadOnly Property NestedTypeProtectionLevel _
            As ProtectionLevels _
            Implements IParameterRule.NestedTypeProtectionLevel
            Get 
                Return ProtectionLevels.Public Or _
                       ProtectionLevels.Family Or _
                       ProtectionLevels.Assembly
            End Get
        End Property
      
        ReadOnly Property MemberProtectionLevel As ProtectionLevels _
            Implements IParameterRule.MemberProtectionLevel
            Get 
                Return ProtectionLevels.Public Or _
                       ProtectionLevels.Family
            End Get
        End Property

        ' Set the IRule property values.
           
        ReadOnly Property Name As String _
            Implements IParameterRule.Name
            Get 
                Return "Do not use delegate parameters (SDK sample 1)"
            End Get
        End Property

        ReadOnly Property Description As String _
            Implements IParameterRule.Description
            Get 
                Return "Company policy states that parameters " & _
                       "should not be delegates."
            End Get
        End Property

        ReadOnly Property LongDescription As String _
            Implements IParameterRule.LongDescription
            Get 
                Return "Methods that require delegates should " & _
                       "be redesigned. Consider Imports the " & _
                       ".NET event model."
            End Get
        End Property

        ReadOnly Property MessageLevel As MessageLevel _
            Implements IParameterRule.MessageLevel
            Get 
                Return MessageLevel.CriticalError
            End Get
        End Property

        ReadOnly Property CertaintyHigh As Integer _
            Implements IParameterRule.CertaintyHigh
            Get 
                Return 99 
            End Get
        End Property

        ReadOnly Property CertaintyLow As Integer _
            Implements IParameterRule.CertaintyLow
            Get 
                Return 99
            End Get
        End Property

        ReadOnly Property GroupOwner As String _
           Implements IParameterRule.GroupOwner
           Get 
                Return "FxCop Custom Rules Team"
            End Get
        End Property

        ReadOnly Property DevOwner As String _
            Implements IParameterRule.DevOwner
            Get 
                Return "Jane Developer"
            End Get
        End Property

        ReadOnly Property Url As String _
            Implements IParameterRule.Url
            Get 
                Return "http://www.example.com"
            End Get
        End Property

        ReadOnly Property Email As String _
            Implements IParameterRule.Email
            Get 
                Return "JaneD@example.com"
            End Get
        End Property
      
        ' Implement the IRule Methods.

        Function DisplayResolution(value As Object ) As String _
            Implements IParameterRule.DisplayResolution

            Return String.Format( _
                CultureInfo.CurrentUICulture, _
                "'{0}' cannot be used as a parameter In an " & _
                "externally visible method.", _
                value.ToString())
        End Function

        Function LoadResolution(value As XmlNode) As Object _
            Implements IParameterRule.LoadResolution

            Return value.InnerText
        End Function

        Sub SaveResolution(writer As XmlWriter, value As Object) _
            Implements IParameterRule.SaveResolution

            writer.WriteString(value.ToString())
        End Sub

        Sub BeforeAnalysis Implements IParameterRule.BeforeAnalysis
        End Sub

        Sub AfterAnalysis Implements IParameterRule.AfterAnalysis
        End Sub
    
    End Class
End Namespace