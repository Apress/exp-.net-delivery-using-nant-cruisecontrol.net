// ParametersAreNotDelegatesWithData.cs

using System;
using System.Reflection;
using Microsoft.Tools.FxCop.Sdk;
using Microsoft.Tools.FxCop.Sdk.Reflection;

namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples
{
    public class ParametersAreNotDelegatesWithData : 
                    BaseReflectionRule, IParameterRule
    {
        private int hitCounter;

        public ParametersAreNotDelegatesWithData() :
            base("ParametersAreNotDelegatesWithData", 
                 "ParametersAreNotDelegatesResources", 
                 typeof(ParametersAreNotDelegatesWithData).Assembly) {}

        public object Check(Module parentModule, 
                            ParameterInfo parameter)
        {
            Type parameterType = parameter.ParameterType;

            if (parameterType.IsSubclassOf(typeof(Delegate)))
            {
                hitCounter++;

                // Pass the expected arguments to the analysis message.
                return GetResolution(parameterType.Name, 
                                     hitCounter.ToString());
            }
            else
            {
                return null;
            }
        }

        public override void BeforeAnalysis()
        {
            // Reset hitCounter for each new analysis.
            hitCounter = 0;
        }

        public override ProtectionLevels NestedTypeProtectionLevel 
        { 
            get
            {
                return ProtectionLevels.Public | 
                       ProtectionLevels.Family | 
                       ProtectionLevels.NestedAssembly;
            }
        } 
    }   
}