' ParametersAreNotDelegatesWithData.vb

Imports System
Imports System.Reflection
Imports Microsoft.Tools.FxCop.Sdk
Imports Microsoft.Tools.FxCop.Sdk.Reflection

Namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples

    Public Class ParametersAreNotDelegatesWithData 
        Inherits BaseReflectionRule
        Implements IParameterRule

        Private hitCounter As Integer

        Sub New
            MyBase.New( _
            "ParametersAreNotDelegatesWithData", _
            "ParametersAreNotDelegatesResources", _
            GetType(ParametersAreNotDelegatesWithData).Assembly)
        End Sub

        Function Check(parentModule As System.Reflection.Module, _
            parameter As ParameterInfo) As Object _
            Implements IParameterRule.Check

            Dim parameterType As Type = parameter.ParameterType

            If parameterType.IsSubclassOf(GetType([Delegate])) Then
                hitCounter = hitCounter + 1

                ' Pass the expected arguments to the analysis message.
                Return GetResolution(parameterType.Name, _
                                     hitCounter.ToString())
            Else
                Return Nothing
            End If
        End Function

        Overrides Sub BeforeAnalysis()

            ' Reset hitCounter for each new analysis.
            hitCounter = 0
        End Sub

        Overrides Readonly Property NestedTypeProtectionLevel _
            As ProtectionLevels

            Get
                Return ProtectionLevels.Public Or _ 
                       ProtectionLevels.Family Or _
                       ProtectionLevels.NestedAssembly
            End Get
        End Property

    End Class
End Namespace