// ParametersAreNotDelegatesTrace.cs

#define TRACE

using System;
using System.Reflection;
using Microsoft.Tools.FxCop.Sdk;
using Microsoft.Tools.FxCop.Sdk.Reflection;
using System.Diagnostics;
using System.IO;

namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples
{
    public class ParametersAreNotDelegatesTrace : 
                    BaseReflectionRule, IParameterRule
    {
        public ParametersAreNotDelegatesTrace() :
            base("ParametersAreNotDelegatesTrace", 
                 "ParametersAreNotDelegatesResources", 
                 typeof(ParametersAreNotDelegatesTrace).Assembly) {}

        public object Check(Module parentModule, 
                            ParameterInfo parameter)
        {
            Type parameterType = parameter.ParameterType;

            // Tracing code.
            if (TraceManager.TraceParameters.Enabled)
            {
                Trace.Write("ParametersAreNotDelegatesTrace - Check ");

                // If true, output maximum information.
                if (TraceManager.MainSwitch.TraceVerbose)
                {
                    Trace.Write(
                        parameter.Name + " " + parameterType.Name);
                }

                // Start a new line.
                Trace.WriteLine("");
            }

            if (parameterType.IsSubclassOf(typeof(Delegate)))
            {
                return GetResolution(parameterType.Name);
            }
            else
            {
                return null;
            }
        }

        public override ProtectionLevels NestedTypeProtectionLevel 
        { 
            get
            {
                return ProtectionLevels.Public | 
                       ProtectionLevels.Family | 
                       ProtectionLevels.NestedAssembly;
            }
        } 
    }   
}