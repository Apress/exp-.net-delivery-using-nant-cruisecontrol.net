' ParametersAreNotDelegatesTrace.vb

Imports System
Imports System.Reflection
Imports Microsoft.Tools.FxCop.Sdk
Imports System.Diagnostics
Imports System.IO
Imports Microsoft.Tools.FxCop.Sdk.Reflection

Namespace Microsoft.Tools.FxCop.Sdk.Docs.Samples

    Public Class ParametersAreNotDelegatesTrace 
        Inherits BaseReflectionRule
        Implements IParameterRule

        Sub New
            MyBase.New( _
            "ParametersAreNotDelegatesTrace", _
            "ParametersAreNotDelegatesResources", _
            GetType(ParametersAreNotDelegatesTrace).Assembly)
        End Sub

        Function Check(parentModule As System.Reflection.Module, _
            parameter As ParameterInfo) As Object _
            Implements IParameterRule.Check

            Dim parameterType As Type = parameter.ParameterType

            ' Tracing code.
            If TraceManager.TraceParameters.Enabled Then
                Trace.Write("ParametersAreNotDelegatesTrace - Check ")

                ' If True, output maximum information.
                If TraceManager.MainSwitch.TraceVerbose Then
                    Trace.Write(parameter.Name & " " & _
                                parameterType.Name)
                End If

                ' Start a new line.
                Trace.WriteLine("")
            End If

            If parameterType.IsSubclassOf(GetType([Delegate])) Then
                Return GetResolution(parameterType.Name)
            Else
                Return Nothing
            End If
        End Function

        Overrides Readonly Property NestedTypeProtectionLevel _
            As ProtectionLevels

            Get
                Return ProtectionLevels.Public Or _ 
                       ProtectionLevels.Family Or _
                       ProtectionLevels.NestedAssembly
            End Get
        End Property

    End Class
End Namespace